"""
src/run_dashboard.py

Launches a local HTTP web server to serve the interactive CRISPR gRNA optimization dashboard.
"""

import http.server
import socketserver
import webbrowser
import subprocess
import sys
from pathlib import Path

PORT = 8000
SRC_DIR = Path(__file__).resolve().parent
PROJECT_ROOT = SRC_DIR.parent
DASHBOARD_DIR = PROJECT_ROOT / "dashboard"

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(DASHBOARD_DIR), **kwargs)

def main():
    # Generate dashboard first using the generator script in the same directory
    print("Generating dashboard...")
    subprocess.run([sys.executable, str(SRC_DIR / "generate_dashboard.py")], check=True)
    
    print(f"Starting dashboard server at http://localhost:{PORT} ...")
    webbrowser.open(f"http://localhost:{PORT}")
    with socketserver.TCPServer(("", PORT), Handler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("
Dashboard server stopped.")

if __name__ == "__main__":
    main()
